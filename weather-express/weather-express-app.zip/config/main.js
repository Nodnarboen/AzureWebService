module.exports = {
  
weatherserviceUri: "https://apacbootcamp-weather-service.azurewebsites.net/weather",

redisHost: "apacbootcamp-redis.redis.cache.windows.net",
redisPort: 6379,
redisPass: "q8QoaeibhknNUY8YJYwAnjjPE5sRp2KDd+FQcnIF6a0=",

    port: 8100,
    portS: 8581
};
-
