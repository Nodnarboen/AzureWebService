module.exports = {
  
weatherserviceUri: "https://bootcamp20-weather-service.azurewebsites.net/weather",

redisHost: "bootcamp20-redis.redis.cache.windows.net",
redisPort: 6379,
redisPass: "2rG79Y0GYFZICkAgfb1VvlKmWSBV2XvKMSR2ng4aj28=",

    port: 8100,
    portS: 8581
};