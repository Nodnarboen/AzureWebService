# weather-express

To run this nifty little weather-express app, make sure that the `weather-service-restify` app is up and running on port `8810`.
Then start it with

    node bin/www

and then visit 

    http://localhost:8100/current/?loc=Linz

in your browser. You *should* see stuff now.

Take a look at `~/config/main.js` for available configuration options (like Redis configuration).# vboot-azure
# vboot-azure
